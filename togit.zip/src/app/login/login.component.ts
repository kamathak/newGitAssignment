import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HardcodedAuthenticationService } from '../service/hardcoded-authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username ='sachin'
  password = ''
  errormessage='Invalid Credentials :('
  invalidCredentials=false

  constructor(private route:Router,
    private hardcodedAuthenticationService:HardcodedAuthenticationService
    ) { }

  ngOnInit(): void {
  }

  handleLogin(){
    //console.log(this.username)
    //if(this.username==="sachin" && this.password==="sachin")
    if(this.hardcodedAuthenticationService.authenticate(this.username,this.password))
    {
      this.route.navigate(['welcome', this.username])
      this.invalidCredentials=false
    }
    else{
      this.invalidCredentials=true
    }
  }

}
