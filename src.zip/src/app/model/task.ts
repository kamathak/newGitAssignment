export class Task {

    constructor(public id:number, public task:string,public priority:number, public parentTask:string, public startDate:Date, public endDate:Date){

    }
    
}
