import { Rule } from '@angular-devkit/schematics';
import { Schema as ModuleOptions } from './schema';
export default function (options: ModuleOptions): Rule;
