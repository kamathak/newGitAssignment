import { Rule } from '@angular-devkit/schematics';
import { Schema as E2eOptions } from './schema';
export default function (options: E2eOptions): Rule;
