# Installation
> `npm install --save @types/jasminewd2`

# Summary
This package contains type definitions for jasminewd2 (https://github.com/angular/jasminewd).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/jasminewd2

Additional Details
 * Last updated: Mon, 05 Nov 2018 22:48:02 GMT
 * Dependencies: jasmine
 * Global values: afterAll, afterEach, beforeAll, beforeEach, fit, it, jasmine, xit

# Credits
These definitions were written by Sammy Jelin <https://github.com/sjelin>, George Kalpakas <https://github.com/gkalpak>.
