export interface CustomReporterResult extends jasmine.CustomReporterResult {
    duration?: string;
}
