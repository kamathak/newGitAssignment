import { Rule } from '../engine/interface';
export declare function move(from: string, to?: string): Rule;
